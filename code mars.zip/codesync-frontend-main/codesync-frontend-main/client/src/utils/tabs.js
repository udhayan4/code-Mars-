export default {
    FILES: "Files",
    CLIENTS: "Clients",
    CHATS: "Chats",
    SETTINGS: "Settings",
}
