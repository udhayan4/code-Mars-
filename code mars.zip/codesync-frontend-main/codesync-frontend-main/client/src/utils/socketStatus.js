const socketStatus = {
    CONNECTING: "connecting",
    CONNECTED: "connected",
    FAILED: "failed",
}

export default socketStatus
